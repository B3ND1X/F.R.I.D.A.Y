<p align="center">
  <img src="https://upload.wikimedia.org/wikipedia/en/4/40/F.R.I.D.A.Y._%28Marvel_Comics%29.jpg" alt="F.R.I.D.A.Y. Marvel" />
</p>

## F.R.I.D.A.Y - Functional Responsive Intelligent Digital Assistant for You ##

[Click here to visit F.R.I.D.A.Y](https://b3nd1x.github.io/F.R.I.D.A.Y/index.html)

