const fs = require('fs');
const path = require('path');
const express = require('express');
const bodyParser = require('body-parser');
const { exec } = require('child_process');
const cors = require('cors'); // Import CORS package

const app = express();
const port = 3000;

// Enable CORS for all origins
app.use(cors());

// Set the PulseAudio server path for pactl to work properly
process.env.PULSE_SERVER = '/run/user/1000/pulse/native';

// Middleware to parse JSON requests
app.use(bodyParser.json());

// Control volume endpoint
app.post('/control-volume', (req, res) => {
    const { volume } = req.body;

    // Ensure volume is within valid range (0-100)
    if (volume < 0 || volume > 100) {
        return res.status(400).json({ status: 'error', message: 'Volume must be between 0 and 100' });
    }

    // Construct the pactl command
    const command = `pactl set-sink-volume @DEFAULT_SINK@ ${volume}%`;

    // Execute the pactl command to control volume
    exec(command, (error, stdout, stderr) => {
        if (error) {
            console.error(`exec error: ${error}`);
            return res.status(500).json({ status: 'error', message: 'Failed to control volume' });
        }

        // Return a success response
        console.log(stdout);
        res.json({ status: 'success', message: `Volume set to ${volume}%` });
    });
});

// Create a file
app.post('/create-file', (req, res) => {
    const { fileName } = req.body;
    const filePath = path.join(__dirname, fileName);

    fs.writeFile(filePath, '', (err) => {
        if (err) {
            return res.status(500).json({ status: 'error', message: 'Error creating the file' });
        }
        res.json({ status: 'success', message: `File '${fileName}' created` });
    });
});

// Delete a file
app.post('/delete-file', (req, res) => {
    const { fileName } = req.body;
    const filePath = path.join(__dirname, fileName);

    fs.unlink(filePath, (err) => {
        if (err) {
            return res.status(500).json({ status: 'error', message: 'Error deleting the file' });
        }
        res.json({ status: 'success', message: `File '${fileName}' deleted` });
    });
});

// Find a file
app.post('/find-file', (req, res) => {
    const { fileName } = req.body;
    const filePath = path.join(__dirname, fileName);

    fs.access(filePath, fs.constants.F_OK, (err) => {
        if (err) {
            return res.json({ status: 'error', message: 'File not found' });
        }
        res.json({ status: 'success', path: filePath });
    });
});

// Copy a file
app.post('/copy-file', (req, res) => {
    const { source, destination } = req.body;

    fs.copyFile(source, destination, (err) => {
        if (err) {
            return res.status(500).json({ status: 'error', message: 'Error copying the file' });
        }
        res.json({ status: 'success', message: `File copied from '${source}' to '${destination}'` });
    });
});

// Open a file or directory
app.post('/open-path', (req, res) => {
    const { path: filePath } = req.body;

    fs.access(filePath, fs.constants.F_OK, (err) => {
        if (err) {
            return res.status(500).json({ status: 'error', message: 'Error opening the path' });
        }
        // For now, simply "open" the file (could add more functionality to launch apps or open files)
        res.json({ status: 'success', message: `Opened ${filePath}` });
    });
});

// Add the screenshot functionality
app.post('/take-screenshot', (req, res) => {
    // Execute the xfce4-screenshooter command to take a full-screen screenshot
    exec('xfce4-screenshooter -f', (error, stdout, stderr) => {
        if (error) {
            console.error(`exec error: ${error}`);
            return res.status(500).json({ status: 'error', message: 'Failed to take screenshot' });
        }

        if (stderr) {
            console.error(`stderr: ${stderr}`);
            return res.status(500).json({ status: 'error', message: 'Error while taking screenshot' });
        }

        console.log(stdout);
        res.json({ status: 'success', message: 'Screenshot taken successfully' });
    });
});

// Application command map
const commandMap = {
    "apturl": "apturl %u",
    "bluetooth adapters": "blueman-adapters",
    "bluetooth manager": "blueman-manager",
    "compizconfig settings manager": "ccsm",
    "drawing": "drawing %U",
    "new window": "drawing --new-window",
    "new image": "drawing --new-tab",
    "edit image in clipboard": "drawing --edit-clipboard",
    "compiz": "compiz",
    "compton": "compton",
    "uxtterm": "uxterm",
    "xterm": "xterm",
    "firefox web browser": "firefox",
    "open a new window": "firefox -new-window",
    "open a new private window": "firefox -private-window",
    "access prompt": "/usr/libexec/gcr-prompter",
    "view file": "/usr/bin/gcr-viewer",
    "gdebi package installer": "gdebi-gtk %f",
    "geoclue demo agent": "/usr/libexec/geoclue-2.0/demos/agent",
    "keyboard layout": "gkbd-keyboard-display",
    "disk image mounter": "gnome-disk-image-mounter %U",
    "disk image writer": "gnome-disks --restore-disk-image %U",
    "online accounts": "gnome-online-accounts-gtk",
    "google chrome": "/usr/bin/google-chrome-stable %U",
    "new window": "/usr/bin/google-chrome-stable",
    "new incognito window": "/usr/bin/google-chrome-stable --incognito",
    "google maps": "kde-geo-uri-handler --coordinate-template \"https://www.google.com/maps/@<LAT>,<LON>,<Z>z\" --query-template \"https://www.google.com/maps/search/<Q>\" --fallback \"https://www.google.com/maps/\" %u",
    "character map": "gucharmap",
    "firewall configuration": "gufw",
    "reactivate hp laserjet 1018/1020 after reloading paper": "/usr/share/foo2zjs/hplj10xx_gui.tcl",
    "hypnotix": "hypnotix",
    "input method": "im-config",
    "texinfo": "info",
    "celluloid": "celluloid %U",
    "new window": "celluloid --new-window",
    "kde connect": "systemsettings kcm_kdeconnect",
    "trash": "kcmshell5 kcm_trash",
    "libreoffice calc": "libreoffice --calc %U",
    "libreoffice writer": "libreoffice --writer %U",
    "libreoffice draw": "libreoffice --draw %U",
    "libreoffice impress": "libreoffice --impress %U",
    "libreoffice xslt based filters": "libreoffice %U",
    "login window": "pkexec lightdm-settings",
    "light locker settings": "/usr/bin/light-locker-settings",
    "hardware locality lstopo": "lstopo",
    "menu editor": "/usr/bin/menulibre",
    "metacity": "metacity",
    "backup tool": "mintbackup",
    "desktop settings": "mintdesktop",
    "driver manager": "driver-manager",
    "software manager": "mintinstall",
    "software sources": "pkexec mintsources",
    "usb image writer": "mintstick -m iso",
    "usb stick formatter": "mintstick -m format",
    "update manager": "mintupdate",
    "welcome screen": "mintwelcome",
    "mint window manager": "window-manager-launcher",
    "mpv media player": "mpv --player-operation-mode",
    "networkmanager applet": "nm-applet",
    "advanced network configuration": "nm-connection-editor",
    "onboard": "onboard",
    "openstreetmap": "kde-geo-uri-handler --coordinate-template \"https://www.openstreetmap.org/#map",
    "about me": "/usr/bin/mugshot",
    "disk usage analyzer": "baobab %U",
    "calculator": "gnome-calculator",
    "disks": "gnome-disks",
    "events and tasks reminders": "/usr/libexec/evolution-data-server/evolution-alarm-notify",
    "evolution data server oauth2 handler": "/usr/libexec/evolution-data-server/evolution-oauth2-handler %u",
    "archive manager": "file-roller %U",
    "rhythmbox": "rhythmbox %U",
    "passwords and keys": "seahorse %u",
    "kde connect": "kdeconnect-app",
    "warpinator": "warpinator",
    "screenshot": "xfce4-screenshooter",
    "xfce terminal": "xfce4-terminal",
    "web browser": "exo-open --launch WebBrowser %u",
    "file manager": "exo-open --launch FileManager %u",
    "mail reader": "exo-open --launch MailReader %u",
    "text editor": "xed %U",
    "accessibility": "xfce4-accessibility-settings",
    "settings manager": "xfce4-settings-manager",
    "document viewer": "xreader %U",
    "image viewer": "xviewer %U",
    "help": "yelp %u"
};



// Launch application endpoint
app.post('/launch-application', (req, res) => {
    const appName = req.body.appName ? req.body.appName.toLowerCase() : '';
    const normalizedAppName = appName.replace(/\s+/g, '').toLowerCase();

    console.log('Received appName:', appName);
    console.log('Normalized appName:', normalizedAppName);

    let matchedCommand = '';
    for (let key in commandMap) {
        const normalizedKey = key.toLowerCase().replace(/\s+/g, '');
        if (normalizedKey.includes(normalizedAppName)) {
            matchedCommand = commandMap[key];
            break;
        }
    }

    if (matchedCommand) {
        console.log('Launching command:', matchedCommand);

        // Dynamically set the DISPLAY environment variable
        const display = process.env.DISPLAY || ':0'; // Default to ':0' if DISPLAY is not set
        process.env.XAUTHORITY = '/home/superuser/.Xauthority'; // Replace with your actual username
        process.env.DISPLAY = display;

        // First attempt to use sudo to run the command as a regular user
        const commandToRun = `sudo -u superuser ${matchedCommand}`; // Replace 'superuser' with your actual username

        exec(commandToRun, { env: process.env }, (error, stdout, stderr) => {
            if (error) {
                console.error('Exec error:', error);
                // Fallback to xdg-open if the initial approach fails
                console.log('Trying xdg-open as fallback...');
                exec(`xdg-open ${matchedCommand}`, { env: process.env }, (fallbackError, fallbackStdout, fallbackStderr) => {
                    if (fallbackError) {
                        console.error('Fallback Exec error:', fallbackError);
                        return res.status(500).json({ error: `Fallback Exec error: ${fallbackError.message}` });
                    }
                    if (fallbackStderr) {
                        console.error('Fallback Exec stderr:', fallbackStderr);
                        return res.status(500).json({ error: `Fallback Exec stderr: ${fallbackStderr}` });
                    }
                    console.log('Fallback Exec stdout:', fallbackStdout);
                    res.json({ message: `Launched ${appName} using fallback method` });
                });
                return; // Exit from the initial attempt
            }
            if (stderr) {
                console.error('Exec stderr:', stderr);
                return res.status(500).json({ error: `Exec stderr: ${stderr}` });
            }
            console.log('Exec stdout:', stdout);
            res.json({ message: `Launched ${appName}` });
        });
    } else {
        console.log('Unknown application:', appName);
        res.status(400).json({ error: 'Unknown application' });
    }
});


// Shutdown system
app.post('/shutdown', (req, res) => {
    exec('shutdown -h now', (error, stdout, stderr) => {
        if (error) {
            console.error(`Exec error: ${error}`);
            return res.status(500).json({ status: 'error', message: 'Failed to shutdown the system' });
        }
        res.json({ status: 'success', message: 'System is shutting down' });
    });
});

// Reboot system
app.post('/reboot', (req, res) => {
    exec('reboot', (error, stdout, stderr) => {
        if (error) {
            console.error(`Exec error: ${error}`);
            return res.status(500).json({ status: 'error', message: 'Failed to reboot the system' });
        }
        res.json({ status: 'success', message: 'System is rebooting' });
    });
});


// Lock the screen
app.post('/lock-screen', (req, res) => {
    exec('/usr/bin/xflock4', (error, stdout, stderr) => {
        if (error) {
            console.error(`Exec error: ${error}`);
            return res.status(500).json({ status: 'error', message: 'Failed to lock the screen' });
        }
        res.json({ status: 'success', message: 'Going to sleep' });
    });
});










// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});

